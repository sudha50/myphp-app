<!DOCTYPE html>
<html>
<body>

<h1>My first PHP page</h1>

<?php
echo "version 1";
?> 

</body>
</html>

